const mongo = require("../mongo")
const profileschema = require("../Schemas/profile-schema")
const coinsCache = {}
const winsCache = {}
const lossesCache = {}
const cardsCache = {}
module.exports = (client) => {}
module.exports.findprofile = async(msg) => {
  const { author } = msg;
  const { id } = author;
    return await mongo().then(async (mongoose) =>{
      try {
        const result = await profileschema.findOne({_id: id})
        return result ? true : false;
      } finally {
        mongoose.connection.close()
      }
    })
  }
  
module.exports.findMbCoins = async(msg) => {
  const { author } = msg;
  const { id } = author;
  const cashedvalue = coinsCache[id]
  if (cashedvalue || cashedvalue == 0) return cashedvalue
  return await mongo().then(async (mongoose) =>{
    try {
      console.log('mbcoins')
      const result = await profileschema.findOne({_id: id})
      coinsCache[id] = result.mbcoins
      return result.mbcoins;
    } finally {
      mongoose.connection.close()
    }
  })
}

module.exports.findWins = async(msg) => {
  const { author } = msg;
  const { id } = author;
  const cashedvalue = winsCache[id]
  if (cashedvalue || cashedvalue == 0) return cashedvalue
  return await mongo().then(async (mongoose) =>{
    try {
      console.log('wins')
      const result = await profileschema.findOne({_id: id})
      winsCache[id] = result.wins
      return result.wins;
    } finally {
      mongoose.connection.close()
    }
  })
}
module.exports.findLosses = async(msg) => {
  const { author } = msg;
  const { id } = author;
  const cashedvalue = lossesCache[id]
  if (cashedvalue || cashedvalue == 0) return cashedvalue
  return await mongo().then(async (mongoose) =>{
    try {
      console.log('losses')
      const result = await profileschema.findOne({_id: id})
      lossesCache[id] = result.losses
      return result.losses;
    } finally {
      mongoose.connection.close()
    }
  })
}

 module.exports.findCards = async(msg) => {
  const { author } = msg;
  const { id } = author;
  const cashedvalue = cardsCache[id]
  if (cashedvalue || cashedvalue == 0) return cashedvalue
  return await mongo().then(async (mongoose) =>{
    try {
      console.log('cards')
      const result = await profileschema.findOne({_id: id})
      cardsCache[id] = result.cards.length
      return result.cards.length
    } finally {
      mongoose.connection.close()
    }
  })
 }

// Use Collection.countDocuments or Collection.estimatedDocumentCount instead