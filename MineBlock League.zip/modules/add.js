const mongo = require("../mongo")
const profileschema = require("../Schemas/profile-schema")

module.exports = (client) => {}

module.exports.addprofile = async(msg) => {
    const { author } = msg;
    const { id } = author;
    await mongo().then(async (mogoose) => {
        try {
            await new profileschema({
                _id: id,
                mbcoins: 0,
                wins: 0,
                losses: 0,
            }).save()
        } finally {
            mogoose.connection.close();
        }
    })
}