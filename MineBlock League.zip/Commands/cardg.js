const mongo = require('../mongo');
const profileSchema = require('../Schemas/profile-schema');

module.exports.run = async (bot, msg, args) => {
    const { author } = msg;
    const { id } = author;
   return  await mongo().then(async (mongoose) => {
      try{
        await profileSchema.findOneAndUpdate({
            _id: id
        },{
            $push:{
                cards: [
                    {
                        HPS: 100,
                        ATK: 100,
                        DEF: -1,
                        SPD: -2,
                        PRE: -3,
                        PRC: -31.54,
                        AMT: 0,
                        AMTUP: 1,
                        NME: "TU",
                        moves: [
                            {
                                name: "lupo",
                                damage: 15.4,
                                description: "5"
                            }
                        ]
                    }
                ]
            }
        })
      }
      finally{
        mongoose.connection.close();
      }
    })
  }
  module.exports.help = {
    name: "gcard",
    aliases:[]
  }