const mongo = require('../mongo');
const messageCountSchema = require('../Schemas/count-schema');
module.exports.run = async (bot, msg, args) => {
  const { author } = msg;
  const { id } = author;
  let count;
  await mongo().then(async (mongoose) => {
    try{
      const r = await messageCountSchema.findOneAndUpdate({
        _id: id 
      }, {
        $inc: {
          counter: 1
        },
      },
      {
        upsert: true,
        new: true
      }).exec();
    count = r.counter;
    }
    finally{
      mongoose.connection.close();
    }
  })
  msg.reply(`Il contatatore è stato aumentato a ${count}`);
}
module.exports.help = {
  name: "count",
  aliases:[]
}

