const { MessageEmbed } = require('discord.js');
const coins = require ('../modules/find');
//const  canvacord  = require("canvacord");
module.exports.run = async(bot, msg) => {
    const mbcoins = await coins.findMbCoins(msg)
    const wins = await coins.findWins(msg)
    const losses = await coins.findLosses(msg)
    const cards = await coins.findCards(msg)
    //const cards =  await coins.lengtharr(msg)
    //msg.reply(cards)
    const profileEmbed = new MessageEmbed()
        .setColor('#0099ff')
        .setAuthor(msg.author.username,msg.author.avatarURL())
        .addFields(
            { name: 'Cards', value: `\`${cards}/9\`` , inline: true},
            { name: 'Mb coins', value: `\`${mbcoins}\``, inline: true},
            { name: '\u200B', value: '\u200B' },
            { name: 'Wins', value: `\`${wins}\``, inline: true},
            { name: 'Losses', value: `\`${losses}\``, inline: true},

        )
    msg.channel.send(profileEmbed);
  }
  
  module.exports.help = {
    name: "profile"
  }