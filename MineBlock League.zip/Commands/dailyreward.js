const mongo = require("../mongo")
const ms = require('parse-ms-js')
const drSchema = require('../Schemas/profile-schema.js')


module.exports.run = async(bot, msg) => {
    const { author } = msg;
    const { id } = author;

    await mongo().then(async mongoose => {
        try {
            const result = await drSchema.findOne({_id: id})
            let timeout = 86400000
            if(timeout - (Date.now() - result.daily) > 0) {
                let timeleft = ms(timeout- (Date.now() - result.daily))
                return msg.reply(`You've already claimed your daily reward, try again after:\n${timeleft.hours} hours , ${timeleft.minutes} minutes , ${timeleft.seconds} seconds`)
            }
            result.daily = Date.now()
            await result.save()
            msg.reply(`You've claimed your daily rewards`)
        } finally {
            mongoose.connection.close()
        }
    })
}

module.exports.help = {
    name: "dr",
    aliases:[]
}