const { MessageEmbed } = require('discord.js');
const { MessageAttachment } = require('discord.js');
const mongo = require('../mongo');
const profile = require('../modules/find');
const profileschema = require("../Schemas/profile-schema")
const pagination = require('discord.js-pagination')
module.exports.run = async (bot, msg, args) => {
  const { author } = msg;
  const { id } = author;
  const n = await profile.findCards(msg)
  let pages = []
  return await mongo().then(async (mongoose) =>{
    try {
        const result = await profileschema.findOne({_id: id})
        for(let i = 0; i < n; i++){
        //const attachment = new MessageAttachment(`./imgs/${result.cards[i].NME}.png`,`${result.cards[i].NME}.png`);
        let imagePath = `./imgs/${result.cards[i].NME}.png`;
        console.log(imagePath)
        const p = new MessageEmbed()
        .setTitle(`page ${i+1}`)
        .setDescription(result.cards[i].NME)
        .attachFiles({ attachment: imagePath, name: 'imgs.png' })
        .setImage('attachment://imgs.png');
       pages.push(p)
        }
    const emoji = ["⏪","⏩"]
    console.log(pages)
    return pagination(msg,pages,emoji).catch(err => console.log(err))
    } finally {
      mongoose.connection.close()
    }
  })
}
module.exports.help = {
  name: "cards",
  aliases:[]
}