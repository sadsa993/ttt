//const mongo = require("../mongo")
//const profileschema = require("../Schemas/profile-schema")
const find = require("../modules/find")
const add = require("../modules/add")

module.exports.run = async(bot, msg) => {
const s = await find.findprofile(msg)

if (s == true) msg.reply('You already have an account!');
else { 
  msg.reply('Your account has been created')
  add.addprofile(msg)
}

}
module.exports.help = {
  name: "start",
  aliases:[]
}

