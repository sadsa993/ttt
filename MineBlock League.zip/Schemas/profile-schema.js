const mongoose = require('mongoose');

const cardsmoves = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    damage: {
        type: Number,
        required: true
    },
    description: {
        type: String,
        required: true
    }
})

const cardsSchema = mongoose.Schema({
    // Hit points
    HPS: {
        type: Number,
        required: true
    },
    // Attack
    ATK: {
        type: Number,
        required: true
    },
    // Defense
    DEF: {
        type: Number,
        required: true
    },
    // Speed
    SPD: {
        type: Number,
        required: true
    },
    // Precision
    PRE: {
        type: Number,
        required: true
    },
    // Price
    PRC: {
        type: Number,
        required: true
    },
    // Amount
    AMT: {
        type: Number,
        required: true
    },
    //ammount for upgrade
    AMTUP: {
        type: Number,
        required: true
    },
    // Name
    NME: {
        type: String,
        required: true
    },
    moves: [cardsmoves]
})
const profileSchema = mongoose.Schema({
    _id: {
        type: String,
        required: true
    },
    mbcoins: {
        type: Number,
        required: true
    },
    wins: {
        type: Number,
        required: true
    },
    losses: {
        type: Number,
        required: true
    },
    cards: [cardsSchema],
    daily:{
        type: Number
    }
    }
)
module.exports = mongoose.model('profile', profileSchema);