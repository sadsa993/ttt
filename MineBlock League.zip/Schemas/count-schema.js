const mongoose = require('mongoose');

const counterSchema = mongoose.Schema({
  //the user id
  _id: {
    type: String,
    required: true
  },
  //how many messages they have sent
  counter: {
    type: Number,
    required: true,
  },
})
module.exports = mongoose.model('counter', counterSchema);
