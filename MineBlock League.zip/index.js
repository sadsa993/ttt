const Discord = require('discord.js');
const shis = require('./config.json');
//const mongo = require('./mongo');
//const ms = require("ms");
const fs = require('fs');
const find  = require('./modules/find');
const prefix = shis.prefix;
const token =  shis.token;
const bot = new Discord.Client({disableEveryone: true});
bot.commands = new Discord.Collection();
fs.readdir("./commands/", (err, files) =>{
	if (err) console.log(err);
	let jsfiles = files.filter(f => f.split(".").pop() === "js");
	if (jsfiles.length <= 0){
		console.log("No commands to load!");
		return;
	}
	console.log(`Loading ${jsfiles.length} commands!`);
	jsfiles.forEach((f, i) =>{
		let props = require(`./commands/${f}`);
		console.log(`${i + 1}:${f} loaded!`);
		bot.commands.set(props.help.name, props);
	});
});

// start 

bot.on('ready', async () => {
	console.log('MineBlock League is ready!');
	const arrstatus = [
		`${bot.guilds.cache.size} servers!`,
		`!help`
	];
	let index  = 0;
	setInterval(() => {
		if(index === arrstatus.length) index = 0
		const status = arrstatus[index]
		bot.user.setActivity(status,{type:"WATCHING"}).catch(console.error)
		index++
	}, 5000);
});
  bot.on('message', async msg =>{
	const check = await find.findprofile(msg)
	let messageArray = msg.content.split(/\s+/g);
	let command = messageArray[0];
	let args = messageArray.slice(1);
    if(!command.startsWith(prefix)) return;
	let cmd = bot.commands.get(command.slice(prefix.length));
	if(command.slice(prefix.length) != "start" && command.slice(prefix.length) != "help")
	if(check == true);
	else{
		msg.reply('In order to do this please create an account first!\n``!start``')
		return
	}
	if(cmd) cmd.run(bot,msg,args);

});


bot.login(token);
